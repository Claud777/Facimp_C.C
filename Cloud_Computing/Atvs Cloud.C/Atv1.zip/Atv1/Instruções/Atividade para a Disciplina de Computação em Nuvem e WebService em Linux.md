#ADS #pratica 

![[Atividade única do semestre (rsrsrsrs).pdf]]

1. Gerente de Projetos: Manu • Responsável por coordenar as atividades do grupo, garantir o cumprimento dos prazos e assegurar que todos os requisitos e recursos necessários estejam devidamente documentados e implementados. 
2. Gerente de Redes: Tristan e JL • Focado na configuração da infraestrutura de rede, incluindo a configuração de servidores, gerenciamento de virtualização e contêineres, e a integração dos serviços em uma rede distribuída. 
3. Gerente de Segurança: Claud • Responsável por aplicar camadas de segurança na infraestrutura, garantindo a proteção contra vulnerabilidades e implementando políticas de segurança nos servidores. 
4. Gerente de Implementação: Luis • Encabeça a instalação, configuração e monitoramento dos servidores, garantindo que toda a infraestrutura esteja funcionando corretamente e de acordo com os requisitos estabelecidos

Funções de pesquisa:
1. Manu: diretrizes da ISO9001 para documentação e implementação
2. Tristan: Conteiners em servidores linux
3. Claud: camadas de segurança e monitoramento
4. Luis: hospedagens de sistemas e sites, com base em estabilidade, disponibilidade e integridade dos servidores

![[Segurança e monitoramento de servidores Linux]]
#ADS 

[[VM em C.C]]

- O projeto:
	O plano é criar dois servidores: Um servidor alocado em uma Maquina Virtual (VM) utilizando a plataforma de virtualização VmWare e o sistema Linux Debian, dentro do servidor colocaremos um Docker e um contêiner.
	Foi sugerida a hospedagem de um site dentro deste servidor para ser usado na apresentação do projeto.

	Obs:
	Como o objetivo final desse projeto é a realização de uma atividade conjunta entre as turmas de CloudCom e CyberSec, o servidor deve estar preparado para receber ataques realizados pela classe de red-team

- Segurança:
	Eu, o encarregado pela segurança do servidor fui incumbido de compreender e aplicar camadas de segurança e monitoramento de acesso no mesmo, as camadas de segurança seguem um embasamento em normas de cyber segurança divulgadas por órgãos competentes, tendo como referencia um TCC feito por estudantes em 2002, eu redigi os mesmos padrões de segurança e irei adapta-los para nosso uso: ![[Segurança e monitoramento de servidores Linux]]
	Referencia: -> [[MONOGRAFIA_Segurança computacional segurança em servidores linux em camadas.pdf]]

- Sugestões:
	Foi trabalhada a possibilidade de usar o software Proxmox para o gerenciamento do servidor porém, a partir de uma analise de caso de uso, foi concluído que o mesmo só seria viável no ramo empresarial por trabalhar melhor com servidores dedicados e que permanecem ligados o tempo todo, relatado em detalhes no arquivo a seguir: [[Proxmox.Integer]]
	
	Tendo em vista os itens citados acima, a conclusão obtida é que se faz necessário apenas o uso do software para a criação e uso da maquina virtual e do software de monitoramento, no nosso caso utilizaremos o Zabixx: [[Zabixx.integer]]
	
	[NGINX](https://www.hostinger.com.br/tutoriais/o-que-e-nginx#:~:text=NGINX%2C%20pronunciado%20“engine-ex,lançado%20em%20Outubro%20de%202004.) A ideia de usar o Nginx no servidor apareceu a partir do network com outros desenvolvedores, o NginX é um software para servidores que disponibiliza varias ferramentas para uso em controle de servidores web, sendo ideal para lidar com um grande fluxo de requisições em um site, além de possibilitar uma otimização do acesso web do servidor ele também fornece ferramentas de segurança para o mesmo.

	<iframe
		  id="inlineFrameExample"
		  title="Inline Frame Example"
		  width="800"
		  height="400"
		  src="https://blog.eveo.com.br/nginx">
	</iframe>

	O Nginx fornece ferramentais para monitoramento de acessos ao servidor, como Log de acessos e de erros, obtendo informações sobre o requisitante e o requisito, quanto aos logs de erros, pode se obter informações como o código do erro e o arquivo de origem. A partir de uma analise dos logs de acesso e dos logs de erros, pode-se obter uma boa informação sobre as tentativas de invasão ao seu servidor e as principais brechas exploradas, se tornando assim uma ferramenta importante de auxilio no monitoramento do servidor

	<iframe
		  id="inlineFrameExample"
		  title="Inline Frame Example"
		  width="800"
		  height="400"
		  src="https://pt.linkedin.com/advice/1/how-can-you-use-nginx-logs-detect-mitigate-opgae?lang=pt">
	</iframe>	
	
- Red Hat: A Red Hat é uma empresa de software reconhecida e popular no mundo da cyber segurança nesse artigo eles disponibilizam boas praticas e ações que auxiliam na melhoria da segurança de um servidor [...]
	[Documentação Red Hat](https://docs.redhat.com/pt/documentation/red_hat_enterprise_linux/6/html/security_guide/index#idm140084973585824)
- Firewalld: Ferramenta utilizada para proteção do Linux: Partindo do pressuposto uso de ferramentas para melhoria da segurança de servidores linux, o Firewalld é mais uma ferramenta para controle de acesso a servidores linux, atuando como firewall, como seu proprio nome já diz
	[Firewalld](https://hackmd.io/@RATM/BJBJkZmZ3?utm_source=preview-mode&utm_medium=rec)


O Proxmox é uma distro Linux de código aberto com a funcionalidade voltada para a virtualização e integração de sistemas de containers, sendo muito usada no ramo profissional para a criação de maquinas AVS e servidores, com ele é possível criar, gerenciar e utilizar varias maquinas virtuais alocadas em um único computador, possibilitando uma praticidade na utilização das maquinas virtuais, sua instalação é relativamente fácil, sendo necessários apenas um pen-drive bootavel com o software do proxmox, após a instalação, o único momento em que se faz necessário o uso de uma interface gráfica na maquina onde está sendo instalada o Proxmox, é no momento em que será necessário obter o IP do servidor para acesso ao Dashboard.

Em uma analise de caso de uso, se torna perceptível que apesar de ser uma ferramenta util para a criação de maquinas virtuais, o Proxmox tem seu uso mais efetivo em maquinas com destino exclusivamente voltado para função de servidores, no caso de nosso exercicio, onde iremos criar uma maquina virtual em um computador de uso pessoal, o Proxmox se torna desnecessário, já que as configurações da maquina podem ser feitas pelo proprio software virtualizador como VmWare ou OracleVB.

Outro fator que torna inviável o uso do Proxmox no projeto é o custo gerado pela necessidade de uma maquina especifica para a função de servidor, a mesma precisaria ficar ligada o tempo todo para receber as requisições de usuários, e no nosso caso tal maquina serviria apenas para fins didaticos, sendo desnecessário a sua existência após o termino do projeto.

Fica claro a capacidade da ferramenta e da possibilidade de uso da mesma em maquinas para uso de ambientes profissionais, o conhecimento e aprendizado adquirido sobre a mesma poderá ser util futuramente em ambientes empresariais ou ainda ser utilizado na criação de servidores NAS para uso pessoal.

<iframe
		  id="inlineFrameExample"
		  title="Inline Frame Example"
		  width="800"
		  height="400"
		  src="https://diolinux.com.br/video/crie-seu-servidor-em-casa-com-proxmox.html#:~:text=O%20PROXMOX%20é%20uma%20distro,que%20já%20apresentamos%20por%20aqui!">
</iframe>	